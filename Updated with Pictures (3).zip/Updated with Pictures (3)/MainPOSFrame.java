import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/** A product is represented as "Product" in all usages. */
abstract class Product {
    private String name;
    private double price;
    private String imagePath;

    public Product(String name, double price, String imagePath) {
        this.name = name;
        this.price = price;
        this.imagePath = imagePath;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getImagePath() { return imagePath; }

    public ImageIcon getImageIcon() {
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource(imagePath));
            Image scaled = icon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (Exception e) {

            return new ImageIcon(new BufferedImage(80, 80, BufferedImage.TYPE_INT_ARGB));
        }
    }

    public abstract String getCategory();
}

class FoodItem extends Product {
    public FoodItem(String name, double price, String imagePath) {
        super(name, price, imagePath);
    }

    @Override
    public String getCategory() {
        return "Food";
    }
}

class DrinkItem extends Product {
    public DrinkItem(String name, double price, String imagePath) {
        super(name, price, imagePath);
    }

    @Override
    public String getCategory() {
        return "Drink";
    }
}

/** Each item added to cart is represented as CartItem. */
class CartItem {
    private Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public void incrementQuantity() { quantity++; }

    public void decrementQuantity() {
        if (quantity > 0) quantity--;
    }

    public double getTotalPrice() {
        return product.getPrice() * quantity;
    }
}

/** The Cart, which holds the list of one or multiple CartItem. It allows for items to be added in, or for the cart to be cleared. It also calculates for the Subtotal, Tax, and Total.*/
class Cart {
    private List<CartItem> items = new ArrayList<>();

    public void addProduct(Product product) {
        for (CartItem item : items) {
            if (item.getProduct().getName().equals(product.getName())) {
                item.incrementQuantity();
                return;
            }
        }
        items.add(new CartItem(product, 1));
    }

    public void removeProduct(String productName) {
        Iterator<CartItem> iterator = items.iterator();
        while (iterator.hasNext()) {
            CartItem item = iterator.next();
            if (item.getProduct().getName().equals(productName)) {
                if (item.getQuantity() > 1) {
                    item.decrementQuantity();
                } else {
                    iterator.remove();
                }
                break;
            }
        }
    }

    public void clear() {
        items.clear();
    }

    public List<CartItem> getItems() {
        return items;
    }

    public double getSubtotal() {
        return items.stream().mapToDouble(CartItem::getTotalPrice).sum();
    }

    public double getTax() {
        return getSubtotal() * 0.12;
    }

    public double getTotal() {
        return getSubtotal() + getTax();
    }
}

/**The button panel to add products to Cart. It also separates products by category.*/
class ProductPanel extends JPanel {
    public ProductPanel(List<Product> products, Cart cart, Runnable onCartUpdated) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); // vertical stacking
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Group products by category
        Map<String, List<Product>> grouped = new LinkedHashMap<>();
        for (Product p : products) {
            grouped.computeIfAbsent(p.getCategory(), k -> new ArrayList<>()).add(p);
        }

        // Create a panel for each category
        for (Map.Entry<String, List<Product>> entry : grouped.entrySet()) {
            String category = entry.getKey();
            List<Product> categoryProducts = entry.getValue();

            JPanel categoryPanel = new JPanel(new GridLayout(0, 3, 10, 10));
            categoryPanel.setBorder(BorderFactory.createTitledBorder(category));

            for (Product p : categoryProducts) {
                JButton button = new JButton("<html><center>" + p.getName() + "<br>₱" + p.getPrice() + "</center></html>");
                button.setIcon(p.getImageIcon());
                button.setHorizontalTextPosition(SwingConstants.CENTER);
                button.setVerticalTextPosition(SwingConstants.BOTTOM);
                button.addActionListener(e -> {
                    cart.addProduct(p);
                    onCartUpdated.run();
                });
                categoryPanel.add(button);
            }

            add(categoryPanel);
            add(Box.createVerticalStrut(10));
        }
    }
}

/**CartPanel, displays the Cart list and shows product names, prices, and totals.*/
class CartPanel extends JPanel {
    private JTable table;
    private JLabel subtotalLabel, taxLabel, totalLabel;
    private DefaultTableModel model;

    public CartPanel() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new Object[]{"Item", "Qty", "Price", "Total"}, 0);
        table = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel totalsPanel = new JPanel(new GridLayout(3, 2));
        subtotalLabel = new JLabel("Subtotal: ₱0.00");
        taxLabel = new JLabel("Tax: ₱0.00");
        totalLabel = new JLabel("Total: ₱0.00");

        totalsPanel.add(subtotalLabel);
        totalsPanel.add(taxLabel);
        totalsPanel.add(totalLabel);

        add(totalsPanel, BorderLayout.SOUTH);
    }

    public JTable getTable() {
        return table;
    }

    public void updateCart(Cart cart) {
        model.setRowCount(0);
        for (CartItem item : cart.getItems()) {
            model.addRow(new Object[]{
                    item.getProduct().getName(),
                    item.getQuantity(),
                    String.format("₱%.2f", item.getProduct().getPrice()),
                    String.format("₱%.2f", item.getTotalPrice())
            });
        }
        subtotalLabel.setText(String.format("Subtotal: ₱%.2f", cart.getSubtotal()));
        taxLabel.setText(String.format("Tax: ₱%.2f", cart.getTax()));
        totalLabel.setText(String.format("Total: ₱%.2f", cart.getTotal()));
    }
}

/** Display screen at top of register. */
class RegisterDisplay extends JPanel {
    private JLabel messageLabel;

    public RegisterDisplay() {
        setLayout(new BorderLayout());
        setBackground(Color.LIGHT_GRAY);
        setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 3));

        messageLabel = new JLabel("Welcome! Please select an item...", SwingConstants.CENTER);
        messageLabel.setForeground(Color.BLACK);
        messageLabel.setFont(new Font("Consolas", Font.BOLD, 20));
        messageLabel.setOpaque(false);

        add(messageLabel, BorderLayout.CENTER);
    }

    public void showMessage(String message) {
        messageLabel.setText(message);
    }
}

/** Main POS Frame */
public class MainPOSFrame extends JFrame {
    private Cart cart = new Cart();
    private CartPanel cartPanel;
    private RegisterDisplay display;

    public MainPOSFrame() {
        setTitle("Simple POS System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(950, 750);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        display = new RegisterDisplay();
        add(display, BorderLayout.NORTH);

        //Images
        List<Product> products = List.of(
                new DrinkItem("Hazelnut", 80.00, "/imagefoods/hazelnut.png"),
                new DrinkItem("Americano", 90.00, "/imagefoods/americano.png"),
                new DrinkItem("Cappuccino", 120.00, "/imagefoods/cappuccino.png"),
                new DrinkItem("Matcha", 130.00, "/imagefoods/matcha.png"),
                new DrinkItem("Mocha", 140.00, "/imagefoods/mocha.png"),
                new DrinkItem("Macchiato", 110.00, "/imagefoods/macchiato.png"),
                new FoodItem("Chicken Sandwich", 130.00, "/imagefoods/chicken_sandwich.png"),
                new FoodItem("Pancakes", 100.00, "/imagefoods/pancakes.png"),
                new FoodItem("Waffles", 120.00, "/imagefoods/waffles.png"),
                new FoodItem("Fries", 70.00, "/imagefoods/fries.png"),
                new FoodItem("Cheesecake", 110.00, "/imagefoods/cheesecake.png"),
                new FoodItem("Pasta", 180.00, "/imagefoods/pasta.png")
        );

        // Panels
        cartPanel = new CartPanel();
        ProductPanel productPanel = new ProductPanel(products, cart, () -> {
            cartPanel.updateCart(cart);
            display.showMessage("Item added! Total: ₱" + String.format("%.2f", cart.getTotal()));
        });

        // Control buttons
        JPanel controlPanel = new JPanel();
        JButton removeBtn = new JButton("Remove Selected Item");
        JButton checkoutBtn = new JButton("Checkout");
        JButton clearBtn = new JButton("Clear Cart");

        removeBtn.addActionListener(e -> {
            int selectedRow = cartPanel.getTable().getSelectedRow();
            if (selectedRow != -1) {
                String productName = cartPanel.getTable().getValueAt(selectedRow, 0).toString();
                cart.removeProduct(productName);
                cartPanel.updateCart(cart);
                display.showMessage(productName + " removed!");
            } else {
                display.showMessage("No item selected to remove!");
            }
        });

        checkoutBtn.addActionListener(e -> {
            display.showMessage("Processing checkout...");
            showCheckoutDialog();
        });

        clearBtn.addActionListener(e -> {
            cart.clear();
            cartPanel.updateCart(cart);
            display.showMessage("Cart cleared!");
        });

        controlPanel.add(removeBtn);
        controlPanel.add(clearBtn);
        controlPanel.add(checkoutBtn);

        add(productPanel, BorderLayout.CENTER);
        add(cartPanel, BorderLayout.EAST);
        add(controlPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void showCheckoutDialog() {
        JOptionPane.showMessageDialog(this,
                String.format("Total to pay: ₱%.2f", cart.getTotal()),
                "Checkout", JOptionPane.INFORMATION_MESSAGE);

        display.showMessage("Payment received. Thank you!");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainPOSFrame::new);
    }
}
